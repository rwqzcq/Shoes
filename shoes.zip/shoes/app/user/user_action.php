<?php
return [
    'login' => [
        'name'          => '用户登录',//用户操作名称
        'score'         => 1,//更改积分，可以为负
        'coin'          => 0,//更改金币，可以为负
        'cycle_time'    => 1,//周期时间值
        'cycle_type'    => 1,//周期类型;0:不限;1:按天;2:按小时;3:永久
        'reward_number' => 1,//奖励次数
        'url'           => '',//执行操作的url
    ]
];