<?php	return array (
  '耐克/:id' => 
  array (
    0 => 'portal/Article/index?cid=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '阿迪/:id' => 
  array (
    0 => 'portal/Article/index?cid=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '李宁/:id' => 
  array (
    0 => 'portal/Article/index?cid=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '安踏/:id' => 
  array (
    0 => 'portal/Article/index?cid=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
      'cid' => '\d+',
    ),
  ),
  '耐克' => 
  array (
    0 => 'portal/List/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  '阿迪' => 
  array (
    0 => 'portal/List/index?id=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  '李宁' => 
  array (
    0 => 'portal/List/index?id=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
  '安踏' => 
  array (
    0 => 'portal/List/index?id=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\d+',
    ),
  ),
);