<?php
//000000000000
 exit();?>
a:2:{s:20:"portal/Article/index";a:4:{i:0;a:1:{s:4:"vars";a:1:{s:3:"cid";s:1:"1";}}i:1;a:1:{s:4:"vars";a:1:{s:3:"cid";s:1:"2";}}i:2;a:1:{s:4:"vars";a:1:{s:3:"cid";s:1:"3";}}i:3;a:1:{s:4:"vars";a:1:{s:3:"cid";s:1:"4";}}}s:17:"portal/List/index";a:4:{i:0;a:1:{s:4:"vars";a:1:{s:2:"id";s:1:"1";}}i:1;a:1:{s:4:"vars";a:1:{s:2:"id";s:1:"2";}}i:2;a:1:{s:4:"vars";a:1:{s:2:"id";s:1:"3";}}i:3;a:1:{s:4:"vars";a:1:{s:2:"id";s:1:"4";}}}}