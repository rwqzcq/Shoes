<?php

return ['plugin_demo_hello_world'=>'Hello,Plugin!'];